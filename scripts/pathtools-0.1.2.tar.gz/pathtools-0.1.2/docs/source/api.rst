.. include:: global.rst.inc

.. api_reference:

=============
API Reference
=============

`pathtools.path`
================

.. automodule:: pathtools.path


`pathtools.patterns`
========================

.. automodule:: pathtools.patterns

.. toctree::
   :maxdepth: 2
